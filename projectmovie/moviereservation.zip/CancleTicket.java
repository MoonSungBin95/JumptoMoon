package moviereservation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CancleTicket {

	public void Cancle(Connection conn, ArrayList<consumer> addr) {
		// 예매현황 취소(=0) 상태로 만듦
		String sql = "UPDATE bookingstatus SET TicketStatus = false WHERE Id = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, sql);
			pstmt.close();
			System.out.println("취소되었습니다.");
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	} // end of method 
	
} // end of class
