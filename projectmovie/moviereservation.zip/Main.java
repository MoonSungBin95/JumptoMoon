package moviereservation;

import java.text.SimpleDateFormat;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		RRTotal.GetRating();
		
		SimpleDateFormat sDate = new SimpleDateFormat("yyyyMMdd");
		Scanner scan = new Scanner(System.in);
		System.out.println(sDate.format(new Date()));
		
		
	}

}
