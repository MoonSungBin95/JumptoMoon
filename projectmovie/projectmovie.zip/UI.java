package projectmovie;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Iterator;
public class UI {
   
   public void Run() {
      Scanner scan = new Scanner(System.in);
      Prompt prompt = new Prompt();
      MovieMethod mm = new MovieMethod();
      
      String input = "";
      int num = 0;
      
main :   while(true) {
         prompt.Prompt_main();
         num = Integer.parseInt(scan.nextLine());   
         switch(num) {
         case 1:  // 영화 예매
            mm.BuyTicket();           
            break;
            
         case 2: // 예매 확인
        	prompt.Prompt_main_CheckReserv();
            mm.check();
            break;
            
         case 3: // 예매 취소
        	 prompt.Prompt_main_cancelTicket();
        	 mm.cancleTicket();
            break;
            
         case 4: // 회원 가입
        	 prompt.Prompt_main_RegiMember();
        	 mm.RegiMember();
            break;
            
         case 5: // 죵료하기
            break main;      // 완전히 종료
            
         case 999:
            prompt.Prompt_manager();
            num = Integer.parseInt(scan.nextLine());
            switch(num) {
            case 1:
                prompt.Prompt_manager_RegiMovie();
                mm.RegiMovie();
                
                break;
             case 2:
                prompt.Prompt_manager_Del();
                mm.DelMovieList();
                break;
             case 3:
                prompt.Prompt_manager_NMT();
                mm.NMT();
                break;
             case 4:
                prompt.Prompt_manager_delNMT();
                mm.timeTable_check_and_Delete();
                break; 
            case 5: // 영화 목록 보기
               break;
            case 6: // 회원 목록 보기
               break;
            case 7: // 예매율 확인
            	break;
            case 8: // 첫 화면으로 돌아가기
            	break;
               default :
                  System.out.println("잘못 누르셨습니다.");
                  break;
            }
            break;
            default :
               System.out.println("다시 입력해 주세요");
               break;
         }
         
      }
      
   }
}