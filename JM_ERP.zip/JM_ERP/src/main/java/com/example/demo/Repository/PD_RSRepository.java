package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.PD_RS;

public interface PD_RSRepository extends JpaRepository<PD_RS,Integer>{

}
