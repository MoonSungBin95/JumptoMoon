package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.PD_QCregi;

public interface PD_QCregiRepository extends JpaRepository<PD_QCregi,String>{

}
