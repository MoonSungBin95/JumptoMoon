package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.Mg_Sn;

public interface MG_snRepository extends JpaRepository<Mg_Sn, Integer> {

}
