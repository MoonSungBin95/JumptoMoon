package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.HR_day;

public interface HR_dayRepository extends JpaRepository<HR_day, Integer>{

}
