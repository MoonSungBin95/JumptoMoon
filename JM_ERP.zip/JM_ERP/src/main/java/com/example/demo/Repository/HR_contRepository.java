package com.example.demo.Repository;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.HR_cont;

public interface HR_contRepository extends JpaRepository<HR_cont, Integer>{


}
